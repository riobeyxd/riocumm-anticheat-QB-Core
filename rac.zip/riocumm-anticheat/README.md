# RAC Anti-Cheat System

A comprehensive FiveM anti-cheat system designed to protect your server from various types of cheats and exploits.

> Created by **RioCumm**

## Features

### Detection Capabilities
- Resource Manipulation
  - Unauthorized Resource Start
  - Resource Stop Detection
  - Blacklisted Event Detection
  - Suspicious Event Injection
  - Resource Usage Violation

### Cheat Detection
- Lua Executor Detection
- Detour Function Hook Detection
- External Cheat Injection Detection
- Unauthorized NUI Callback Detection
- Unauthorized Key Press Detection
- Godmode Detection
- Invisibility Detection
- Spectate Mode Abuse
- Super Jump Detection
- NoClip Detection
- Teleport Detection
- Weapon Blacklist Violation
- Vehicle Spawn Abuse
- Illegal Pad Change
- High Damage Modifier Detection

### Economy Protection
- Suspicious Money Increase Detection
- Inventory Item Spam Detection
- Unauthorized Item Injection
- Blacklisted Transaction Detection
- Mass Item Trunk Insertion Detection
- Cash Transfer Monitoring
- Bank Deposit Monitoring
- Blacklisted Currency Source Detection

### Player Verification
- Steam Hex Verification
- License ID Verification
- Rockstar License Verification
- VPN/Proxy Detection
- Fake Ping Spoof Detection
- Ban Attempt Bypass Detection

### System Monitoring
- Player Connection/Disconnection Logging
- Command Injection Detection
- Suspicious Console Command Detection
- Cheat Menu Detection
- Key Combination Detection
- Suspicious Tick Manipulation Detection
- Automated Screenshot System
  - Ban Evidence Collection
  - Suspicious Activity Capture
  - Discord Integration
  - Local Storage Management

### Admin Panel
- Player Management
  - Ban Players
  - Kick Players
  - Change Player Models
  - Take Screenshots
  - Monitor Player Activity
- Real-time Monitoring
- Webhook Integration
- Screenshot Management

## Installation

1. **Download and Place Files**:
   - Download the `riocumm-anticheat` folder
   - Place it in your server's `resources` directory

2. **Install Required Dependencies**:
   ```bash
   # Create a dependencies folder if it doesn't exist
   cd resources
   mkdir dependencies
   cd dependencies

   # Clone screenshot-basic
   git clone https://github.com/citizenfx/screenshot-basic
   
   # Clone keep-alive
   git clone https://github.com/citizenfx/keep-alive
   ```

3. **Configure server.cfg**:
   ```cfg
   # Dependencies
   ensure screenshot-basic
   ensure keep-alive
   
   # Anti-cheat
   ensure riocumm-anticheat
   
   # Screenshot configuration
   set screenshot_basic_token "your_token_here"
   set screenshot_basic_url "your_webhook_url_here"
   ```

4. **Create Required Directories**:
   ```bash
   # Create screenshots directory
   cd resources/riocumm-anticheat
   mkdir screenshots
   ```

5. **Database Setup**:
   - Open your database management tool (phpMyAdmin, HeidiSQL, etc.)
   - Import the following SQL tables:

### SQL Tables

#### Bans Table
```sql
CREATE TABLE IF NOT EXISTS `bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `reason` text NOT NULL,
  `expiration` int(11) NOT NULL,
  `banned_by` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### Anti-Cheat Logs Table
```sql
CREATE TABLE IF NOT EXISTS `anticheat_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` varchar(50) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### Player Violations Table
```sql
CREATE TABLE IF NOT EXISTS `player_violations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` varchar(50) NOT NULL,
  `violation_type` varchar(50) NOT NULL,
  `count` int(11) NOT NULL DEFAULT 1,
  `last_violation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `player_violation` (`player_id`,`violation_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

6. **Configure Discord Webhooks**:
   - Create Discord webhooks for different notification types:
     - Main notifications
     - Detection logs
     - Connection logs
     - Screenshot logs
   - Open `config.lua` and update the webhook URLs:
   ```lua
   RAC.Discord = {
       enabled = true,
       webhooks = {
           main = "YOUR_MAIN_WEBHOOK_URL",
           detections = "YOUR_DETECTIONS_WEBHOOK_URL",
           connections = "YOUR_CONNECTIONS_WEBHOOK_URL",
           screenshots = "YOUR_SCREENSHOTS_WEBHOOK_URL"
       }
   }
   ```

7. **Configure Screenshot Settings**:
   ```lua
   RAC.Screenshot = {
       enabled = true,
       saveLocal = true,
       savePath = "screenshots/",
       encoding = "jpg",
       webhookEnabled = true,
       screenshotOnBan = true,
       screenshotOnDetection = true
   }
   ```

8. **Restart Server**:
   - Restart your FiveM server
   - The anti-cheat system will automatically start

## Configuration

### Screenshot System Setup
1. **Quality Settings**:
   ```lua
   RAC.Settings.screenshotQuality = 0.85    -- Adjust quality (0.1 to 1.0)
   RAC.Settings.screenshotTimeout = 10000   -- Timeout in milliseconds
   ```

2. **Event Triggers**:
   ```lua
   RAC.Screenshot.events = {
       ["rac:detection"] = true,    -- Screenshot on detection
       ["rac:ban"] = true,         -- Screenshot on ban
       ["rac:kick"] = false,       -- Screenshot on kick
       ["rac:warning"] = false     -- Screenshot on warning
   }
   ```

3. **Storage Configuration**:
   - Local storage path can be configured in `RAC.Screenshot.savePath`
   - Discord webhook integration in `RAC.Discord.webhooks.screenshots`
   - Automatic cleanup of old screenshots (configurable retention period)

### Webhook Setup
1. Create a Discord webhook in your server
2. Copy the webhook URL
3. Edit the `webhookURL` variable in `server/admin.lua`:
```lua
local webhookURL = "YOUR_DISCORD_WEBHOOK_URL"
```

### Admin Panel
- Access the admin panel using the `/rac` command
- Only players with `permission_level > 0` can access the panel

## Usage

### Admin Commands
- `/rac` - Open the admin panel
- `/rac screenshot <player>` - Take a screenshot of a player
- `/rac screenshots` - View screenshot history
- Ban players with reason and duration
- Kick players with reason
- Change player models

### Screenshot Management
- Screenshots are automatically taken when:
  - A player is banned
  - Suspicious activity is detected
  - An admin requests a screenshot
- Screenshots are stored:
  - Locally in the configured directory
  - Sent to Discord via webhook
  - Accessible through the admin panel

### Player Verification
When a player joins the server:
1. They will see the message: "RAC: You are being checked"
2. The system verifies their:
   - Steam ID
   - License ID
   - Rockstar License
   - Connection details

### Webhook Notifications
All detected violations are sent to your Discord webhook with:
- Event type
- Player details
- Timestamp
- Additional context

## Security Features

### Screenshot System
- Secure screenshot transmission
- Retry mechanism for failed screenshots
- Quality preservation
- Timestamp and player info embedding
- Automatic Discord integration

### Real-time Monitoring
- Continuous player behavior analysis
- Resource usage tracking
- Event injection detection
- Command monitoring

### Automatic Actions
- Immediate kick for critical violations
- Ban system integration
- Resource protection
- Economy protection

## Troubleshooting

### Common Issues

1. **Screenshots Not Working**
   - Verify screenshot-basic is properly installed
   - Check webhook URLs are correct
   - Ensure proper permissions on screenshots directory
   - Verify keep-alive is running
   - Check server logs for errors

2. **Screenshot Quality Issues**
   - Adjust quality settings in config
   - Check available server memory
   - Verify encoding settings

1. **Admin Panel Not Opening**
   - Check if your account has `permission_level > 0`
   - Verify QB-Core is running properly
   - Check server console for errors

2. **Bans Not Working**
   - Verify SQL tables are imported correctly
   - Check database connection
   - Look for errors in server console

3. **Webhook Notifications Not Sending**
   - Verify webhook URL is correct
   - Check Discord channel permissions
   - Look for errors in server console

4. **Anti-Cheat Not Detecting Violations**
   - Check server logs for errors
   - Verify all resources are started
   - Ensure QB-Core is properly configured

## Support

For support, please send me message:
- Discord: riocumm

## License

Copyright (c) 2025 RioCumm

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Ban System

### Features
- Permanent and temporary bans
- Ban ID tracking system
- Multiple identifier tracking (Steam, License, Discord)
- Admin permission system
- Discord webhook integration
- Ban history and management
- Unban command system

### Ban Commands
1. **Ban Player**:
   ```
   /rban <player_id> <reason>
   ```
   - Requires admin permission
   - Permanently bans player
   - Records all identifiers

2. **Temporary Ban**:
   ```
   /tempban <player_id> <duration_hours> <reason>
   ```
   - Requires admin permission
   - Duration in hours
   - Automatically expires

3. **Unban Player**:
   ```
   /runban <ban_id>
   ```
   - Requires admin permission
   - Removes ban by ID
   - Logs unban action

### Admin Panel Ban Features
- Visual ban interface
- Ban duration selector
- Reason input field
- Ban history viewer
- Active bans counter
- Unban functionality
- Ban search system

### Ban Appeals
1. Players can appeal bans through:
   - Discord server
   - Web panel
   - Support ticket system

2. Appeal process includes:
   - Ban ID verification
   - Reason review
   - Admin decision logging
   - Automatic notification

## Additional Anti-Cheat Features

### Resource Protection
- Hash verification
- File integrity checks
- Injection detection
- Resource restart monitoring
- Unauthorized modification detection

### Network Security
- Packet validation
- Traffic analysis
- Event flooding protection
- Payload verification
- Connection monitoring

### Memory Protection
- Memory scanning
- Pattern detection
- DLL injection prevention
- Memory modification detection
- Process validation

### Entity Validation
- Entity ownership verification
- Entity spawn rate limiting
- Entity modification tracking
- Invalid entity detection
- Entity cleanup system

### Vehicle Protection
- Speed hacking detection
- Vehicle modification validation
- Vehicle spawn monitoring
- Vehicle godmode detection
- Vehicle teleport detection

### Weapon Protection
- Weapon validation
- Damage modification detection
- Rapid fire detection
- Infinite ammo detection
- Weapon modification tracking

### Player Protection
- Health/Armor modification detection
- Coordinate validation
- Speed hacking detection
- Noclip detection
- Spectate abuse prevention

### Menu Detection
- Known menu detection
- Injection pattern recognition
- Menu function detection
- Resource override detection
- Native function monitoring

### Configuration Options
```lua
RAC.Protection = {
    enabled = true,
    resource_validation = true,
    network_validation = true,
    memory_scanning = true,
    entity_validation = true,
    vehicle_protection = true,
    weapon_protection = true,
    player_protection = true,
    menu_detection = true
}

RAC.Limits = {
    max_vehicle_speed = 500.0,
    max_ped_speed = 10.0,
    entity_spawn_rate = 5,
    weapon_fire_rate = 0.1,
    teleport_distance = 100.0
}

RAC.Logging = {
    enabled = true,
    discord_webhook = true,
    database_logging = true,
    console_output = true,
    debug_mode = false
}
```

### Performance Optimization
- Efficient detection methods
- Resource usage monitoring
- Smart detection intervals
- Cached verification
- Optimized ban checks

### False Positive Prevention
- Multiple verification steps
- Detection confidence levels
- Whitelist system
- Exception handling
- Admin override options

### Integration Support
- ESX compatibility
- QBCore compatibility
- vMenu compatibility
- Custom framework support
- API for external resources

### Reporting System
1. **Player Reports**:
   ```lua
   exports['riocumm-anticheat']:reportPlayer(playerId, reason, evidence)
   ```

2. **Auto Reports**:
   - Suspicious activity logging
   - Pattern recognition
   - Threshold monitoring
   - Admin notifications

3. **Report Management**:
   - Admin review interface
   - Evidence collection
   - Action tracking
   - Resolution logging

### Screenshot System
- Automatic screenshot on detection
- Manual admin screenshots
- Secure storage system
- Discord integration
- Evidence management

### API Documentation
```lua
-- Check if player is banned
exports['riocumm-anticheat']:isPlayerBanned(identifier)

-- Get ban information
exports['riocumm-anticheat']:getBanInfo(banId)

-- Add custom detection
exports['riocumm-anticheat']:registerDetection(name, callback)

-- Add custom protection
exports['riocumm-anticheat']:addProtection(name, options)

-- Get detection statistics
exports['riocumm-anticheat']:getStats()
```

### Troubleshooting

#### Common Issues
1. **False Positives**
   - Check whitelist configuration
   - Verify detection thresholds
   - Update detection patterns
   - Review exception logs

2. **Performance Impact**
   - Adjust scan intervals
   - Optimize detection methods
   - Configure resource limits
   - Monitor server impact

3. **Integration Problems**
   - Check framework compatibility
   - Verify event handlers
   - Update resource version
   - Clear cache files

### Best Practices
1. **Server Configuration**
   - Regular updates
   - Proper permissions
   - Secure webhooks
   - Database maintenance

2. **Admin Guidelines**
   - Evidence collection
   - Ban documentation
   - Appeal handling
   - Detection verification

3. **Maintenance**
   - Regular backups
   - Log rotation
   - Database cleanup
   - Pattern updates 