local QBCore = exports['qb-core']:GetCoreObject()
local isAdmin = false

-- Show check message when player joins
Citizen.CreateThread(function()
    Wait(1000) -- Wait for player to fully load
    QBCore.Functions.Notify('RAC: You are being checked', 'primary')
    TriggerServerEvent('riocumm:playerConnected', GetPlayerServerId(PlayerId()), {
        name = GetPlayerName(PlayerId()),
        steam = GetPlayerIdentifier(PlayerId(), 0),
        license = GetPlayerIdentifier(PlayerId(), 1),
        discord = GetPlayerIdentifier(PlayerId(), 2),
        ip = GetPlayerEndpoint(PlayerId())
    })
end)

-- Check admin status
Citizen.CreateThread(function()
    while true do
        local Player = QBCore.Functions.GetPlayerData()
        isAdmin = Player.PlayerData.permission_level > 0
        Citizen.Wait(5000)
    end
end)

-- NUI Callbacks
RegisterNUICallback('getPlayers', function(data, cb)
    if not isAdmin then return end
    TriggerServerEvent('riocumm:getPlayers')
    cb('ok')
end)

RegisterNUICallback('banPlayer', function(data, cb)
    if not isAdmin then return end
    TriggerServerEvent('riocumm:banPlayer', data.targetId, data.reason, data.duration)
    cb('ok')
end)

RegisterNUICallback('kickPlayer', function(data, cb)
    if not isAdmin then return end
    TriggerServerEvent('riocumm:kickPlayer', data.targetId, data.reason)
    cb('ok')
end)

RegisterNUICallback('changePlayerModel', function(data, cb)
    if not isAdmin then return end
    TriggerServerEvent('riocumm:changePlayerModel', data.targetId, data.model)
    cb('ok')
end)

-- Event handlers
RegisterNetEvent('riocumm:updatePlayers')
AddEventHandler('riocumm:updatePlayers', function(players)
    SendNUIMessage({
        type = 'updatePlayers',
        players = players
    })
end)

RegisterNetEvent('riocumm:banResult')
AddEventHandler('riocumm:banResult', function(success)
    SendNUIMessage({
        type = 'banResult',
        success = success
    })
end)

RegisterNetEvent('riocumm:kickResult')
AddEventHandler('riocumm:kickResult', function(success)
    SendNUIMessage({
        type = 'kickResult',
        success = success
    })
end)

RegisterNetEvent('riocumm:modelChangeResult')
AddEventHandler('riocumm:modelChangeResult', function(success)
    SendNUIMessage({
        type = 'modelChangeResult',
        success = success
    })
end)

-- Model change handler
RegisterNetEvent('riocumm:changePlayerModel')
AddEventHandler('riocumm:changePlayerModel', function(model)
    local playerPed = PlayerPedId()
    local modelHash = GetHashKey(model)
    
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Citizen.Wait(0)
    end
    
    SetPlayerModel(PlayerId(), modelHash)
    SetPedDefaultComponentVariation(PlayerPedId())
    
    SetModelAsNoLongerNeeded(modelHash)
end)

-- Toggle admin panel with /rac command
RegisterCommand('rac', function()
    if isAdmin then
        SetNuiFocus(true, true)
        SendNUIMessage({
            type = 'showAdminPanel'
        })
    else
        QBCore.Functions.Notify('You do not have permission to use this command.', 'error')
    end
end)

-- Close admin panel
RegisterNUICallback('closeAdminPanel', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end) 