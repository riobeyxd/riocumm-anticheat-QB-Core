--[[
    RAC AntiCheat Keep-Alive Client
    Handles client-side heartbeat system
]]

local heartbeatInterval = 30000 -- Default interval
local isHeartbeatActive = false

-- Configuration validation
local function ValidateConfig()
    if not RAC then
        print('^1[RAC] Error: RAC configuration table is missing^7')
        return false
    end
    
    local required = {
        {'HeartBeat.enabled', 'boolean'},
        {'Settings.keepAliveInterval', 'number'},
        {'Settings.chatMessages', 'boolean'}
    }
    
    for _, config in ipairs(required) do
        local value = RAC
        for part in config[1]:gmatch('[^.]+') do
            value = value[part]
            if not value then
                print('^1[RAC] Error: Missing configuration: ' .. config[1] .. '^7')
                return false
            end
        end
        if type(value) ~= config[2] then
            print('^1[RAC] Error: Invalid type for ' .. config[1] .. '. Expected ' .. config[2] .. ', got ' .. type(value) .. '^7')
            return false
        end
    end
    return true
end

-- Validate configuration on resource start
CreateThread(function()
    if not ValidateConfig() then
        print('^1[RAC] Keep-alive system disabled due to configuration errors^7')
        RAC.HeartBeat.enabled = false
        return
    end
end)

-- Initialize heartbeat system
RegisterNetEvent('rac:initHeartbeat')
AddEventHandler('rac:initHeartbeat', function(interval)
    heartbeatInterval = interval or 30000
    StartHeartbeat()
end)

-- Start heartbeat loop
function StartHeartbeat()
    if isHeartbeatActive then return end
    isHeartbeatActive = true
    
    CreateThread(function()
        while isHeartbeatActive do
            TriggerServerEvent('rac:keepAlive')
            Wait(heartbeatInterval)
        end
    end)
end

-- Handle heartbeat warnings
RegisterNetEvent('rac:heartbeatWarning')
AddEventHandler('rac:heartbeatWarning', function(warningCount)
    -- Visual feedback for connection issues
    if RAC.Settings.chatMessages then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"RAC", "Connection warning " .. warningCount .. "/3 - Please check your connection"}
        })
    end
end)

-- Stop heartbeat on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        isHeartbeatActive = false
    end
end)

-- Restart heartbeat on resource start
AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        TriggerServerEvent('rac:playerConnected')
    end
end) 