local QBCore = exports['qb-core']:GetCoreObject()
local isMenuOpen = false
local lastPosition = vector3(0, 0, 0)
local lastVelocity = vector3(0, 0, 0)
local lastCheck = 0
local lastWeaponCheck = 0
local lastVehicleCheck = 0

-- Initialize variables
local playerState = {
    isWhitelisted = false,
    isAdmin = false,
    lastCheck = 0
}

-- NUI Variables
local menuVisible = false

-- Initialize anti-cheat
CreateThread(function()
    while true do
        Wait(1000)
        local playerPed = PlayerPedId()
        local playerId = PlayerId()
        
        if not playerState.isWhitelisted then
            -- Check for blacklisted objects
            local objects = GetGamePool('CObject')
            for _, object in ipairs(objects) do
                local model = GetEntityModel(object)
                local modelName = GetEntityArchetypeName(object)
                
                for _, blacklistedObject in ipairs(Config.Blacklist.Objects.list) do
                    if modelName == blacklistedObject then
                        TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_object', {
                            object = blacklistedObject,
                            coords = GetEntityCoords(object)
                        })
                        break
                    end
                end
            end
            
            -- Check for blacklisted weapons
            if Config.Blacklist.Weapons.enabled then
                local currentWeapon = GetSelectedPedWeapon(playerPed)
                for _, weapon in ipairs(Config.Blacklist.Weapons.list) do
                    if currentWeapon == GetHashKey(weapon) then
                        TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_weapon', {
                            weapon = weapon
                        })
                        break
                    end
                end
            end
            
            -- Check for blacklisted vehicles
            if Config.Blacklist.Vehicles.enabled then
                local currentVehicle = GetVehiclePedIsIn(playerPed, false)
                if currentVehicle ~= 0 then
                    local vehicleModel = GetEntityModel(currentVehicle)
                    for _, vehicle in ipairs(Config.Blacklist.Vehicles.list) do
                        if vehicleModel == GetHashKey(vehicle) then
                            TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_vehicle', {
                                vehicle = vehicle
                            })
                            break
                        end
                    end
                end
            end
        end
    end
end)

-- Monitor explosions
AddEventHandler('explosionEvent', function(sender, ev)
    if Config.Blacklist.Explosions.enabled and not playerState.isWhitelisted then
        local explosionType = ev.explosionType
        if Config.Blacklist.Explosions.list[explosionType] then
            TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_explosion', {
                type = Config.Blacklist.Explosions.list[explosionType],
                coords = vector3(ev.posX, ev.posY, ev.posZ),
                owner = sender
            })
        end
    end
end)

-- Check for various cheats
function CheckForCheats(playerPed)
    local currentTime = GetGameTimer()
    if currentTime - lastCheck < 1000 then return end
    lastCheck = currentTime

    -- Noclip detection
    if not IsPedInAnyVehicle(playerPed, false) then
        local currentPosition = GetEntityCoords(playerPed)
        local currentVelocity = GetEntityVelocity(playerPed)
        
        if #(currentPosition - lastPosition) > 10.0 and #currentVelocity < 0.1 then
            TriggerServerEvent('riocumm-anticheat:server:detection', 'noclip', {
                position = currentPosition,
                velocity = currentVelocity
            })
        end
        
        lastPosition = currentPosition
        lastVelocity = currentVelocity
    end

    -- Superjump detection
    if IsPedJumping(playerPed) then
        local jumpHeight = GetEntityHeightAboveGround(playerPed)
        if jumpHeight > Config.DetectionSettings.Superjump.maxHeight then
            TriggerServerEvent('riocumm-anticheat:server:detection', 'superjump', {
                height = jumpHeight
            })
        end
    end

    -- Speedhack detection
    if not IsPedInAnyVehicle(playerPed, false) then
        local speed = GetEntitySpeed(playerPed)
        if speed > Config.DetectionSettings.Speedhack.maxSpeed then
            TriggerServerEvent('riocumm-anticheat:server:detection', 'speedhack', {
                speed = speed
            })
        end
    end
end

-- Check blacklist
function CheckBlacklist()
    local currentTime = GetGameTimer()
    
    -- Check weapons
    if currentTime - lastWeaponCheck > 5000 then
        lastWeaponCheck = currentTime
        if Config.Blacklist.Weapons.enabled then
            local weapon = GetSelectedPedWeapon(PlayerPedId())
            local weaponName = GetWeaponNameFromHash(weapon)
            
            for _, blacklistedWeapon in ipairs(Config.Blacklist.Weapons.list) do
                if weaponName == blacklistedWeapon then
                    TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_weapon', {
                        weapon = weaponName
                    })
                end
            end
        end
    end
    
    -- Check vehicles
    if currentTime - lastVehicleCheck > 5000 then
        lastVehicleCheck = currentTime
        if Config.Blacklist.Vehicles.enabled then
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            if vehicle ~= 0 then
                local vehicleModel = GetEntityModel(vehicle)
                local vehicleName = GetVehicleNameFromHash(vehicleModel)
                
                for _, blacklistedVehicle in ipairs(Config.Blacklist.Vehicles.list) do
                    if string.lower(vehicleName) == string.lower(blacklistedVehicle) then
                        TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_vehicle', {
                            vehicle = vehicleName
                        })
                    end
                end
            end
        end
    end
end

-- Monitor chat for blacklisted keywords
RegisterNetEvent('__cfx_internal:server:chatMessage')
AddEventHandler('__cfx_internal:server:chatMessage', function(source, message)
    if Config.Blacklist.Keywords.enabled then
        for _, keyword in ipairs(Config.Blacklist.Keywords.list) do
            if string.find(string.lower(message), string.lower(keyword)) then
                TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_keyword', {
                    keyword = keyword,
                    message = message
                })
            end
        end
    end
end)

-- Monitor blacklisted events
for _, event in ipairs(Config.Blacklist.Events.list) do
    RegisterNetEvent(event)
    AddEventHandler(event, function()
        TriggerServerEvent('riocumm-anticheat:server:detection', 'blacklisted_event', {
            event = event
        })
    end)
end

-- NUI Menu
RegisterCommand('rac', function()
    if IsPlayerAdmin() then
        ToggleMenu()
    end
end)

function ToggleMenu()
    isMenuOpen = not isMenuOpen
    SetNuiFocus(isMenuOpen, isMenuOpen)
    SendNUIMessage({
        action = "toggleMenu",
        show = isMenuOpen
    })
end

-- NUI Callbacks
RegisterNUICallback('closeMenu', function(data, cb)
    ToggleMenu()
    cb('ok')
end)

RegisterNUICallback('getLogs', function(data, cb)
    TriggerServerEvent('riocumm-anticheat:server:getLogs', function(logs)
        cb(logs)
    end)
end)

-- Register NUI Callback for closing menu
RegisterNUICallback('hideMenu', function(data, cb)
    SetNuiFocus(false, false)
    menuVisible = false
    cb('ok')
end)

-- Register NUI Callback for updating config
RegisterNUICallback('updateConfig', function(data, cb)
    TriggerServerEvent('riocumm-anticheat:server:updateConfig', data)
    cb('ok')
end)

-- Register NUI Callback for kicking player
RegisterNUICallback('kickPlayer', function(data, cb)
    if playerState.isAdmin then
        TriggerServerEvent('riocumm-anticheat:server:kickPlayer', data.playerId)
    end
    cb('ok')
end)

-- Register NUI Callback for banning player
RegisterNUICallback('banPlayer', function(data, cb)
    if playerState.isAdmin then
        TriggerServerEvent('riocumm-anticheat:server:banPlayer', data.playerId)
    end
    cb('ok')
end)

-- Command to toggle menu
RegisterCommand('acmenu', function()
    if playerState.isAdmin then
        ToggleAntiCheatMenu()
    end
end)

-- Function to toggle menu
function ToggleAntiCheatMenu()
    menuVisible = not menuVisible
    SetNuiFocus(menuVisible, menuVisible)
    
    if menuVisible then
        -- Get latest data
        TriggerServerEvent('riocumm-anticheat:server:requestData')
        
        -- Show menu
        SendNUIMessage({
            action = 'showMenu'
        })
    else
        -- Hide menu
        SendNUIMessage({
            action = 'hideMenu'
        })
    end
end

-- Event handler for receiving data from server
RegisterNetEvent('riocumm-anticheat:client:receiveData')
AddEventHandler('riocumm-anticheat:client:receiveData', function(data)
    SendNUIMessage({
        action = 'updateDetections',
        detections = data.detections
    })
    
    SendNUIMessage({
        action = 'updatePlayers',
        players = data.players
    })
    
    SendNUIMessage({
        action = 'updateConfig',
        config = data.config
    })
end)

-- Event handler for new detections
RegisterNetEvent('riocumm-anticheat:client:newDetection')
AddEventHandler('riocumm-anticheat:client:newDetection', function(detection)
    if menuVisible then
        SendNUIMessage({
            action = 'addActivityLog',
            log = {
                timestamp = GetGameTimer(),
                text = string.format('New detection: %s by %s', detection.type, detection.player)
            }
        })
    end
end)

-- Helper functions
function IsPlayerWhitelisted()
    local identifiers = GetPlayerIdentifiers(PlayerId())
    for _, identifier in pairs(identifiers) do
        if whitelistedPlayers[identifier] then
            return true
        end
    end
    return false
end

function IsPlayerAdmin()
    local identifiers = GetPlayerIdentifiers(PlayerId())
    for _, identifier in pairs(identifiers) do
        if adminPlayers[identifier] then
            return true
        end
    end
    return false
end

-- Event handlers
RegisterNetEvent('riocumm-anticheat:client:updateWhitelist')
AddEventHandler('riocumm-anticheat:client:updateWhitelist', function(whitelist)
    whitelistedPlayers = whitelist
end)

RegisterNetEvent('riocumm-anticheat:client:updateAdmins')
AddEventHandler('riocumm-anticheat:client:updateAdmins', function(admins)
    adminPlayers = admins
end) 