--[[
    RAC AntiCheat Configuration
    Created by RioCumm
    
    This file contains all configurable settings for the RAC anticheat system.
    Each section is clearly documented and organized for easy customization.
    
    Documentation:
    - All features can be toggled using boolean values (true/false)
    - Punishments can be set to: "BAN", "KICK", or "LOG"
    - Arrays use table format with either boolean or string values
    - Discord settings require valid webhook URLs
    - Permission levels: "all", "admin", "superadmin"
]]

RAC = {}

-- GENERAL SETTINGS
RAC.Settings = {
    Debug = true,                    -- Enable debug mode for detailed logging
    Locale = "en",                   -- Language setting (currently supports: en)
    txAdminAuth = true,             -- Enable txAdmin authentication
    screenshotModule = "screenshot-basic", -- Screenshot module to use
    screenshotQuality = 0.85,           -- Screenshot quality (0.1 to 1.0)
    screenshotTimeout = 10000,          -- Screenshot timeout in milliseconds
    keepAliveInterval = 30000,          -- Keep-alive check interval
    banIDFormat = 1,                -- Format for ban IDs (1: incremental, 2: unique hash)
    autoSQL = true,                 -- Automatically create required SQL tables
    punishType = "BAN",             -- Default punishment type
    Prefix = "RAC AntiCheat",       -- Prefix for system messages
    showReason = true,              -- Show reason when punishing players
    appealDiscord = "https://discord.gg/yourdiscord", -- Discord appeal link
    pingOnDetect = true,            -- Ping admins on detection
    chatMessages = false,           -- Show detections in chat
    OCR = true,                     -- Enable Optical Character Recognition
    OCRCheckInterval = 60000,       -- OCR check interval in milliseconds
    spoilerIP = true,              -- Hide IP addresses in logs
    maxUsernameLength = -1,         -- Max username length (-1 for unlimited)
    needDiscord = false             -- Require Discord linking
}

-- HEARTBEAT SYSTEM
RAC.HeartBeat = {
    enabled = true,
    maxTime = 30                    -- Maximum time between heartbeats in seconds
}

-- ADMIN MENU CONFIGURATION
RAC.AdminMenu = {
    enable = true,
    backgroundBlur = true,
    espSelf = true,
    espMaxDist = 350.0,
    screenshotTimeout = 3,
    rgb = { 255, 255, 255 },
    permissionLevel = "all",
    allowedIds = {
        "discord:1234",
        "license:123abc"
    }
}

-- FRAMEWORK INTEGRATION
RAC.Framework = {
    framework = "standalone",        -- Framework type (standalone, ESX, QB-Core)
    moneyCheck = true,              -- Enable money monitoring
    moneyCheckType = "both",        -- Money check type (cash, bank, both)
    moneyCheckInterval = 5,         -- Check interval in seconds
    moneyCheckThreshold = 2000000   -- Maximum allowed money amount
}

-- PROTECTED EVENTS
RAC.ProtectedEvents = {
    ["test:event"] = true,
    ["esx:getSharedObject"] = true,
    ["QBCore:GetObject"] = true
}

-- EVENT RATE LIMITING
RAC.EventLimiter = {
    ["test:event"] = 5,             -- Maximum triggers per second
    ["esx:pay"] = 3,
    ["qb-core:pay"] = 3
}

-- DETECTION PUNISHMENTS
RAC.DetectionPunishments = {
    -- Movement Detections
    ["noclip"] = "BAN",
    ["freecam"] = "LOG",
    ["godmode"] = "BAN",
    ["fastrun"] = "LOG",
    ["teleport"] = "LOG",
    ["superjump"] = "BAN",
    ["invisibility"] = "LOG",
    
    -- Combat Detections
    ["aimbot"] = "BAN",
    ["silentaim"] = "BAN",
    ["damagemodifier"] = "BAN",
    ["weaponmodifier"] = "BAN",
    ["infiniteammo"] = "BAN",
    ["rapidfire"] = "BAN",
    
    -- Visual Detections
    ["esp"] = "BAN",
    ["blips"] = "BAN",
    ["thermal"] = "LOG",
    ["nightvision"] = "LOG",
    
    -- Resource Detections
    ["resourcestop"] = "BAN",
    ["resourcestart"] = "LOG",
    ["injection"] = "BAN",
    ["menudetected"] = "BAN"
}

-- CONNECTING CARD
RAC.connectingCard = {
    enabled = true,
    length = 5000                   -- Display time in milliseconds
}

-- WHITELISTED RESOURCES
RAC.whitelistedResources = {
    ["es_extended"] = true,
    ["qb-core"] = true,
    ["mysql-async"] = true,
    ["oxmysql"] = true
}

-- ANTICHEAT FEATURES
RAC.Features = {
    -- UI/Development Protection
    antiNUIDevTools = true,         -- Block developer tools
    antiResourceStop = true,       -- Prevent resource stopping
    antiResourceStart = false,      -- Prevent unauthorized resource starts
    antiModuleStop = true,         -- Prevent module stopping
    
    -- Action Protection
    antiClearTasks = true,         -- Prevent clearing player tasks
    antiGiveWeapons = false,       -- Prevent weapon giving
    antiRemoveWeapons = true,      -- Prevent weapon removal
    antiObjectAttach = true,       -- Prevent object attachment
    antiPlateChange = true,       -- Prevent vehicle plate changes
    antiFold = true,              -- Prevent vehicle folding
    antiKill = true,              -- Prevent force killing
    
    -- Movement Protection
    antiFastRun = true,           -- Prevent speed hacks
    antiTeleport = false,         -- Prevent teleportation
    antiNoClip = true,           -- Prevent no-clip
    antiVehicleNoClip = true,    -- Prevent vehicle no-clip
    antiSuperJump = true,        -- Prevent super jump
    antiInfiniteStamina = true,  -- Prevent infinite stamina
    
    -- Combat Protection
    antiGodMode = true,          -- Prevent god mode
    antiMagicBullet = false,     -- Prevent magic bullets
    antiRapidFire = true,        -- Prevent rapid fire
    antiNoRecoil = true,         -- Prevent no recoil
    antiTaze = true,             -- Prevent taze abuse
    antiSilentAim = true,        -- Prevent silent aim
    antiDamageBoost = true,      -- Prevent damage modification
    antiDefenseBoost = true,     -- Prevent defense modification
    antiExplosiveAmmo = true,    -- Prevent explosive ammo
    antiInfiniteAmmo = true,     -- Prevent infinite ammo
    antiAimbot = true,           -- Prevent aimbot
    
    -- Visual Protection
    antiOverlay = false,         -- Prevent overlays
    antiRadar = false,           -- Prevent player radar
    antiFreeCam = false,         -- Prevent free camera
    antiBlips = false,           -- Prevent player blips
    antiSpectate = true,         -- Prevent spectating
    antiThermal = true,          -- Prevent thermal vision
    antiNightVision = true,      -- Prevent night vision
    
    -- Misc Protection
    antiVDM = true,             -- Prevent vehicle death matching
    antiAIs = true,              -- Prevent AI spawning
    antiMenus = true,            -- Prevent mod menus
    antiSmallPed = true,         -- Prevent small ped model
    antiInvisible = false,       -- Prevent invisibility
    antiStatebagCrash = true,    -- Prevent statebag crashes
    fakeTriggers = true,         -- Enable fake event triggers
    antiSpoofedShot = true       -- Prevent spoofed shots
}

-- BLACKLISTED ELEMENTS
RAC.Blacklists = {
    -- Prop Animations
    propAnimations = {
        ["prop_pencil_01"] = true,
        ["prop_tool_fireaxe"] = true,
        ["prop_speaker_07"] = true,
        ["prop_bskball_01"] = true,
        ["prop_beach_ring_01"] = true,
        ["prop_bongos_01"] = true,
        ["prop_boombox_01"] = true,
        ["prop_tool_broom"] = true,
        ["prop_parking_wand_01"] = true,
        ["prop_tool_shovel"] = true,
        ["prop_fishing_rod_01"] = true,
        ["prop_champ_flute"] = true,
        ["prop_bin_08open"] = true,
        ["prop_phone_ing"] = true,
        ["prop_megaphone_01"] = true,
        ["prop_skid_chair_02"] = true
    },

    -- Food Animations
    foodAnimations = {
        ["sf_prop_sf_apple_01b"] = true,
        ["prop_food_bs_chips"] = true,
        ["prop_cs_hotdog_01"] = true,
        ["prop_cs_hotdog_02"] = true,
        ["bzzz_icecream_strawberry"] = true,
        ["prop_choc_ego"] = true,
        ["prop_taco_01"] = true,
        ["prop_ecola_can"] = true,
        ["prop_cs_burger_01"] = true,
        ["prop_food_bs_coffee"] = true,
        ["prop_beerdusche"] = true,
        ["bzzz_food_xmas_mug_a"] = true,
        ["bzzz_food_xmas_mulled_wine_a"] = true
    },

    -- Explosions
    explosionList = {
        [0] = "GRENADE",
        [1] = "GRENADELAUNCHER",
        [2] = "STICKYBOMB",
        [3] = "MOLOTOV",
        [4] = "ROCKET",
        [5] = "TANKSHELL",
        [36] = "RAILGUN",
        [38] = "FIREWORK",
        [40] = "PROXMINE",
        [43] = "PIPEBOMB",
        [45] = "EXPLOSIVEAMMO",
        [59] = "ORBITAL_CANNON",
        [70] = "RAYGUN"
    },

    -- Blacklisted Names
    badNames = {
        "nigga", "nigger", "n1gger", "n1gg3r", "admin", "moderator", "owner", "coowner",
        "faggot", "kys", "retard", "<script", "<script src", "<script src=", "<script src =",
        "<src =", "<script>", "/>", "moderator", "eulencheats", "eulen", "redengine",
        "susano", "lynxmenu", "atgmenu", "hacker", "rustchance.com", "hellcase.com",
        "youtube.com", "twitch.tv", "chocohax", "https", "http", "www.", "?", "§",
        "pornhub.com", "porn", "pornhub", "fuck server", "orosbu", "hello mothafucka!", "-1 -3"
    },

    -- Blacklisted Chat Messages
    blockedWords = {
        "negre", "negr", "nigga", "nigger", "niggers", "i hate niggers", "nate higgers",
        "retard", "faggots", "faggot", "kys", "keyser", "fuck server", "hello mothafucka!", 
        "-1 -3", "zADS341"
    }
}

-- DISCORD INTEGRATION
RAC.Discord = {
    enabled = true,
    webhooks = {
        main = "YOUR_WEBHOOK_URL",
        detections = "YOUR_WEBHOOK_URL",
        connections = "YOUR_WEBHOOK_URL",
        screenshots = "YOUR_WEBHOOK_URL"
    },
    botName = "RAC AntiCheat System",
    botAvatar = "https://i.imgur.com/YOUR_IMAGE.png",
    embedColor = 16711680,          -- Decimal color code (red: 16711680)
    embedFooter = "RAC AntiCheat System"
}

-- VISUAL SETTINGS
RAC.Visual = {
    notificationDuration = 5000,     -- Duration of notifications in milliseconds
    bannerColor = {255, 165, 0},    -- RGB values for banner color
    textColor = {255, 255, 255},    -- RGB values for text color
    backgroundColor = {0, 0, 0, 200} -- RGBA values for background color
}

-- SCREENSHOT SETTINGS
RAC.Screenshot = {
    enabled = true,                     -- Enable screenshot system
    saveLocal = true,                   -- Save screenshots locally
    savePath = "screenshots/",          -- Local save path (relative to server root)
    encoding = "jpg",                   -- Screenshot encoding (jpg or png)
    webhookEnabled = true,              -- Send screenshots to Discord
    screenshotOnBan = true,            -- Take screenshot when player is banned
    screenshotOnDetection = true,       -- Take screenshot on suspicious activity
    screenshotOnCommand = true,         -- Allow admins to take screenshots
    maxRetries = 3,                     -- Maximum retry attempts for failed screenshots
    retryDelay = 1000,                  -- Delay between retries in milliseconds
    events = {                          -- Events that trigger screenshots
        ["rac:detection"] = true,       -- Take screenshot on detection
        ["rac:ban"] = true,            -- Take screenshot on ban
        ["rac:kick"] = false,          -- Take screenshot on kick
        ["rac:warning"] = false        -- Take screenshot on warning
    }
}

return RAC 