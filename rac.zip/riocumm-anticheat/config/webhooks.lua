Config.Webhooks = {
    -- Main webhook settings
    enabled = true,
    username = "RAC Anti-Cheat",
    avatar_url = "https://i.imgur.com/YOUR_LOGO.png",

    -- Individual webhook URLs
    urls = {
        item_drops = "YOUR_WEBHOOK_URL_HERE",
        vehicle_spawns = "YOUR_WEBHOOK_URL_HERE",
        weapon_usage = "YOUR_WEBHOOK_URL_HERE",
        bans_kicks = "YOUR_WEBHOOK_URL_HERE",
        suspicious_activity = "YOUR_WEBHOOK_URL_HERE",
        admin_actions = "YOUR_WEBHOOK_URL_HERE",
        connections = "YOUR_WEBHOOK_URL_HERE",
        -- New webhook URLs
        inventory_actions = "YOUR_WEBHOOK_URL_HERE",
        bank_transactions = "YOUR_WEBHOOK_URL_HERE",
        player_deaths = "YOUR_WEBHOOK_URL_HERE",
        chat_messages = "YOUR_WEBHOOK_URL_HERE",
        job_actions = "YOUR_WEBHOOK_URL_HERE",
        property_actions = "YOUR_WEBHOOK_URL_HERE",
        trading_actions = "YOUR_WEBHOOK_URL_HERE",
        crafting_actions = "YOUR_WEBHOOK_URL_HERE"
    },

    -- Webhook colors (in decimal)
    colors = {
        item_drops = 3066993,        -- Green
        vehicle_spawns = 15105570,   -- Orange
        weapon_usage = 15158332,     -- Red
        bans_kicks = 10038562,       -- Purple
        suspicious_activity = 15548997, -- Pink
        admin_actions = 3447003,     -- Blue
        connections = 9807270,       -- Gray
        -- New webhook colors
        inventory_actions = 7506394,  -- Teal
        bank_transactions = 15844367, -- Gold
        player_deaths = 0,           -- Black
        chat_messages = 5793266,     -- Light Blue
        job_actions = 12745742,      -- Brown
        property_actions = 11027200,  -- Dark Green
        trading_actions = 15277667,   -- Coral
        crafting_actions = 6323595   -- Purple-Blue
    },

    -- Logging settings
    settings = {
        log_item_drops = true,
        log_vehicle_spawns = true,
        log_weapon_usage = true,
        log_bans_kicks = true,
        log_suspicious_activity = true,
        log_admin_actions = true,
        log_connections = true,
        -- New logging settings
        log_inventory_actions = true,
        log_bank_transactions = true,
        log_player_deaths = true,
        log_chat_messages = true,
        log_job_actions = true,
        log_property_actions = true,
        log_trading_actions = true,
        log_crafting_actions = true,
        
        -- Minimum time between logs (in seconds) to prevent spam
        cooldown = {
            item_drops = 1,
            vehicle_spawns = 1,
            weapon_usage = 1,
            suspicious_activity = 5,
            inventory_actions = 1,
            bank_transactions = 1,
            player_deaths = 1,
            chat_messages = 1,
            job_actions = 1,
            property_actions = 1,
            trading_actions = 1,
            crafting_actions = 1
        }
    }
} 