let config = {
    enabled: true,
    debug: false,
    detectionSettings: {
        weapons: true,
        vehicles: true,
        explosions: true,
        objects: true
    }
};

// Menu state
let menuVisible = false;
let currentTab = 'dashboard';
let activityLog = [];
let detections = [];
let players = [];
let selectedPlayer = null;
let isSpectating = false;

// Vehicles section
let selectedCategory = null;
let selectedVehicle = null;
let vehicles = {
    'Compacts': ['Asbo', 'Blista', 'Brioso', 'Dilettante', 'Issi2', 'Panto', 'Prairie', 'Rhapsody'],
    'Sedans': ['Asea', 'Asterope', 'Emperor', 'Fugitive', 'Glendale', 'Ingot', 'Intruder', 'Premier', 'Primo', 'Regina', 'Stanier', 'Stratum', 'Super Diamond', 'Surge', 'Tailgater', 'Warrener', 'Washington'],
    'SUVs': ['Baller', 'BeeJay XL', 'Cavalcade', 'Granger', 'Gresley', 'Habanero', 'Huntley S', 'Landstalker', 'Mesa', 'Patriot', 'Radius', 'Rocoto', 'Seminole', 'Serrano', 'XLS'],
    'Coupes': ['Cognoscenti Cabrio', 'Exemplar', 'F620', 'Felon', 'Felon GT', 'Jackal', 'Oracle', 'Oracle XS', 'Sentinel', 'Sentinel XS', 'Windsor', 'Windsor Drop', 'Zion', 'Zion Cabrio'],
    'Muscle': ['Blade', 'Buccaneer', 'Chino', 'Clique', 'Coquette BlackFin', 'Deviant', 'Dominator', 'Dukes', 'Gauntlet', 'Hermes', 'Hotknife', 'Phoenix', 'Picador', 'Rat-Loader', 'Ruiner', 'Sabre Turbo', 'Stallion', 'Tampa', 'Vigero', 'Virgo', 'Voodoo'],
    'Sports Classics': ['Ardent', 'Casco', 'Cheburek', 'Cheetah Classic', 'Coquette Classic', 'Dynasty', 'Fagaloa', 'GT500', 'Infernus Classic', 'JB 700', 'Mamba', 'Manana', 'Monroe', 'Peyote', 'Pigalle', 'Rapid GT Classic', 'Retinue', 'Stinger', 'Stinger GT', 'Stromberg', 'Swinger', 'Torero', 'Tornado', 'Turismo Classic', 'Viseris', 'Z-Type'],
    'Sports': ['9F', 'Alpha', 'Banshee', 'Bestia GTS', 'Buffalo', 'Carbonizzare', 'Comet', 'Coquette', 'Elegy', 'Feltzer', 'Furore GT', 'Fusilade', 'Futo', 'Jester', 'Kuruma', 'Lynx', 'Massacro', 'Omnis', 'Penumbra', 'Rapid GT', 'Schafter V12', 'Seven-70', 'Sultan', 'Surano', 'Tropos', 'Verlierer']
};

// Initialize menu
document.addEventListener('DOMContentLoaded', () => {
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(button => {
        button.addEventListener('click', () => {
            switchTab(button.dataset.tab);
        });
    });

    // Close button
    document.getElementById('closeMenu').addEventListener('click', () => {
        hideMenu();
    });

    // Search functionality
    document.getElementById('searchDetections').addEventListener('input', filterDetections);
    document.getElementById('searchPlayers').addEventListener('input', filterPlayers);

    // Settings toggles
    document.getElementById('enableAnticheat').addEventListener('change', (e) => {
        config.enabled = e.target.checked;
        sendToGame('updateConfig', config);
    });

    document.getElementById('debugMode').addEventListener('change', (e) => {
        config.debug = e.target.checked;
        sendToGame('updateConfig', config);
    });

    // Detection settings
    document.getElementById('weaponDetection').addEventListener('change', (e) => {
        config.detectionSettings.weapons = e.target.checked;
        sendToGame('updateConfig', config);
    });

    document.getElementById('vehicleDetection').addEventListener('change', (e) => {
        config.detectionSettings.vehicles = e.target.checked;
        sendToGame('updateConfig', config);
    });

    document.getElementById('explosionDetection').addEventListener('change', (e) => {
        config.detectionSettings.explosions = e.target.checked;
        sendToGame('updateConfig', config);
    });

    document.getElementById('objectDetection').addEventListener('change', (e) => {
        config.detectionSettings.objects = e.target.checked;
        sendToGame('updateConfig', config);
    });

    // Time slider update
    const timeSlider = document.querySelector('.time-slider');
    const timeValue = timeSlider.nextElementSibling;
    timeSlider.addEventListener('input', (e) => {
        timeValue.textContent = e.target.value;
    });

    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // Admin buttons functionality
    document.querySelectorAll('.admin-button').forEach(button => {
        button.addEventListener('click', () => {
            const action = button.getAttribute('data-action');
            
            switch(action) {
                case 'ban_player':
                    showModal('banModal');
                    break;
                case 'kick_player':
                    showModal('kickModal');
                    break;
                case 'teleport_coords':
                    showModal('teleportModal');
                    break;
                default:
                    handleAdminAction(action);
                    break;
            }
        });
    });

    // Model changer
    const modelSelector = document.querySelector('.model-selector');
    const setModelButton = modelSelector.nextElementSibling;
    setModelButton.addEventListener('click', () => {
        const selectedModel = modelSelector.value;
        handleAdminAction('set_model', {
            model: selectedModel
        });
    });

    // ESP options
    document.querySelectorAll('.esp-checkbox input').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            const option = checkbox.id;
            const enabled = checkbox.checked;
            handleAdminAction('toggle_esp', {
                option: option,
                enabled: enabled
            });
        });
    });

    // Announcement system
    const announceInput = document.querySelector('.announce-input');
    const positionSelector = document.querySelector('.position-selector');

    announceInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const text = announceInput.value;
            const position = positionSelector.value;
            const duration = parseInt(timeSlider.value);

            if (text.trim()) {
                handleAdminAction('announce', {
                    text: text,
                    position: position,
                    duration: duration
                });
                announceInput.value = '';
            }
        }
    });

    // Show/Hide UI
    window.addEventListener('message', (event) => {
        if (event.data.type === 'showUI') {
            document.body.style.display = event.data.show ? 'flex' : 'none';
        }
    });

    // Close on Escape
    document.addEventListener('keyup', (e) => {
        if (e.key === 'Escape') {
            fetch(`https://${GetParentResourceName()}/closeUI`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({})
            });
        }
    });

    // Player Search
    document.getElementById('playerSearch').addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        filterPlayers(searchTerm);
    });

    // Player Selection
    document.getElementById('playersList').addEventListener('click', (e) => {
        const row = e.target.closest('tr');
        if (row) {
            document.querySelectorAll('tr').forEach(r => r.classList.remove('selected'));
            row.classList.add('selected');
            selectedPlayer = {
                id: row.dataset.id,
                name: row.dataset.name,
                steamhex: row.dataset.steamhex
            };
        }
    });

    // Action Buttons
    document.querySelectorAll('.action-button').forEach(button => {
        button.addEventListener('click', () => {
            const action = button.getAttribute('data-action');
            if (!selectedPlayer && action !== 'disableSpectate') {
                showNotification('Please select a player first', 'error');
                return;
            }
            handlePlayerAction(action);
        });
    });

    // Disable Spectate Button
    document.getElementById('disableSpectate').addEventListener('click', () => {
        if (isSpectating) {
            handlePlayerAction('disableSpectate');
        }
    });

    // Initialize vehicles section
    initVehiclesSection();
});

// Switch tabs
function switchTab(tabId) {
    currentTab = tabId;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.tab === tabId) {
            btn.classList.add('active');
        }
    });

    // Update tab panels
    document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');

    // Refresh tab content
    refreshTabContent(tabId);
}

// Refresh tab content
function refreshTabContent(tabId) {
    switch (tabId) {
        case 'dashboard':
            updateDashboard();
            break;
        case 'detections':
            updateDetections();
            break;
        case 'players':
            updatePlayers();
            break;
        case 'settings':
            updateSettings();
            break;
    }
}

// Update dashboard
function updateDashboard() {
    document.getElementById('totalPlayers').textContent = players.length;
    document.getElementById('activeBans').textContent = getActiveBans();
    document.getElementById('detectionsToday').textContent = getDetectionsToday();
    updateActivityLog();
}

// Update detections list
function updateDetections() {
    const list = document.getElementById('detectionsList');
    list.innerHTML = '';

    detections.forEach(detection => {
        const item = createDetectionItem(detection);
        list.appendChild(item);
    });
}

// Create detection item
function createDetectionItem(detection) {
    const item = document.createElement('div');
    item.className = 'detection-item';
    item.innerHTML = `
        <div class="detection-header">
            <span class="detection-type">${detection.type}</span>
            <span class="detection-time">${formatTime(detection.timestamp)}</span>
        </div>
        <div class="detection-details">
            <p>Player: ${detection.player}</p>
            <p>Details: ${JSON.stringify(detection.details)}</p>
        </div>
    `;
    return item;
}

// Update players list
function updatePlayers() {
    const list = document.getElementById('playersList');
    list.innerHTML = '';

    players.forEach(player => {
        const item = createPlayerItem(player);
        list.appendChild(item);
    });
}

// Create player item
function createPlayerItem(player) {
    const item = document.createElement('div');
    item.className = 'player-item';
    item.innerHTML = `
        <div class="player-info">
            <span class="player-name">${player.name}</span>
            <span class="player-id">ID: ${player.id}</span>
        </div>
        <div class="player-actions">
            <button onclick="kickPlayer(${player.id})">Kick</button>
            <button onclick="banPlayer(${player.id})">Ban</button>
        </div>
    `;
    return item;
}

// Filter functions
function filterDetections() {
    const search = document.getElementById('searchDetections').value.toLowerCase();
    const type = document.getElementById('filterType').value;

    const filtered = detections.filter(detection => {
        const matchesSearch = detection.player.toLowerCase().includes(search) ||
                            detection.type.toLowerCase().includes(search);
        const matchesType = type === 'all' || detection.type === type;
        return matchesSearch && matchesType;
    });

    const list = document.getElementById('detectionsList');
    list.innerHTML = '';
    filtered.forEach(detection => {
        const item = createDetectionItem(detection);
        list.appendChild(item);
    });
}

function filterPlayers(searchTerm) {
    const filtered = players.filter(player => 
        player.name.toLowerCase().includes(searchTerm) ||
        player.id.toString().includes(searchTerm) ||
        player.steamhex.toLowerCase().includes(searchTerm)
    );
    renderPlayers(filtered);
}

// Utility functions
function formatTime(timestamp) {
    return new Date(timestamp).toLocaleString();
}

function getActiveBans() {
    // Implementation for getting active bans count
    return 0;
}

function getDetectionsToday() {
    const today = new Date().setHours(0, 0, 0, 0);
    return detections.filter(d => new Date(d.timestamp) >= today).length;
}

// NUI Message handlers
window.addEventListener('message', (event) => {
    const data = event.data;

    switch (data.action) {
        case 'showMenu':
            document.getElementById('menu').classList.remove('hidden');
            menuVisible = true;
            refreshTabContent(currentTab);
            break;

        case 'hideMenu':
            hideMenu();
            break;

        case 'updateConfig':
            config = data.config;
            updateSettings();
            break;

        case 'updateDetections':
            detections = data.detections;
            if (currentTab === 'detections') {
                updateDetections();
            }
            break;

        case 'updatePlayers':
            players = data.players;
            if (currentTab === 'players') {
                updatePlayers();
            }
            break;

        case 'addActivityLog':
            activityLog.unshift(data.log);
            if (activityLog.length > 50) {
                activityLog.pop();
            }
            if (currentTab === 'dashboard') {
                updateActivityLog();
            }
            break;
    }
});

// Send message to game
function sendToGame(action, data) {
    fetch(`https://${GetParentResourceName()}/${action}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(data)
    }).then(() => {
        if (!['spectate', 'disableSpectate'].includes(action)) {
            showNotification('Action completed successfully');
        }
    }).catch(() => {
        showNotification('Failed to complete action', 'error');
    });
}

// Menu visibility
function hideMenu() {
    document.getElementById('menu').classList.add('hidden');
    menuVisible = false;
    sendToGame('hideMenu', {});
}

// Player actions
function kickPlayer(playerId) {
    sendToGame('kickPlayer', { playerId });
}

function banPlayer(playerId) {
    sendToGame('banPlayer', { playerId });
}

// Update activity log
function updateActivityLog() {
    const log = document.getElementById('activityLog');
    log.innerHTML = '';

    activityLog.forEach(entry => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        item.innerHTML = `
            <span class="activity-time">${formatTime(entry.timestamp)}</span>
            <span class="activity-text">${entry.text}</span>
        `;
        log.appendChild(item);
    });
}

// Update settings
function updateSettings() {
    document.getElementById('enableAnticheat').checked = config.enabled;
    document.getElementById('debugMode').checked = config.debug;
    document.getElementById('weaponDetection').checked = config.detectionSettings.weapons;
    document.getElementById('vehicleDetection').checked = config.detectionSettings.vehicles;
    document.getElementById('explosionDetection').checked = config.detectionSettings.explosions;
    document.getElementById('objectDetection').checked = config.detectionSettings.objects;
}

// Close menu when clicking outside
document.addEventListener('click', function(event) {
    const container = document.getElementById('mainContainer');
    if (!container.contains(event.target)) {
        fetch(`https://${GetParentResourceName()}/closeMenu`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
    }
});

// Load initial data
loadDashboardData();
loadLogs();
loadBans();
loadSettings();
loadBlacklist();

// Load dashboard data
function loadDashboardData() {
    fetch(`https://${GetParentResourceName()}/getDashboardData`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('activePlayers').textContent = data.activePlayers;
        document.getElementById('detectionsToday').textContent = data.detectionsToday;
        document.getElementById('activeBans').textContent = data.activeBans;
    });
}

// Load logs
function loadLogs() {
    fetch(`https://${GetParentResourceName()}/getLogs`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        const logsBody = document.getElementById('logsBody');
        logsBody.innerHTML = '';
        
        data.logs.forEach(log => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${log.time}</td>
                <td>${log.player}</td>
                <td>${log.type}</td>
                <td>${log.details}</td>
                <td>
                    <button onclick="takeAction('${log.id}', 'kick')">Kick</button>
                    <button class="danger" onclick="takeAction('${log.id}', 'ban')">Ban</button>
                </td>
            `;
            logsBody.appendChild(row);
        });
    });
}

// Load bans
function loadBans() {
    fetch(`https://${GetParentResourceName()}/getBans`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        const bansBody = document.getElementById('bansBody');
        bansBody.innerHTML = '';
        
        data.bans.forEach(ban => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${ban.id}</td>
                <td>${ban.player}</td>
                <td>${ban.reason}</td>
                <td>${ban.date}</td>
                <td>
                    <button onclick="unbanPlayer('${ban.id}')">Unban</button>
                </td>
            `;
            bansBody.appendChild(row);
        });
    });
}

// Load settings
function loadSettings() {
    fetch(`https://${GetParentResourceName()}/getSettings`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('aimbotDetection').checked = data.aimbotDetection;
        document.getElementById('espDetection').checked = data.espDetection;
        document.getElementById('noclipDetection').checked = data.noclipDetection;
        document.getElementById('superjumpDetection').checked = data.superjumpDetection;
        document.getElementById('speedhackDetection').checked = data.speedhackDetection;
    });
}

// Take action on a player
function takeAction(logId, action) {
    fetch(`https://${GetParentResourceName()}/takeAction`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            logId: logId,
            action: action
        })
    })
    .then(() => {
        loadLogs();
        loadDashboardData();
    });
}

// Unban a player
function unbanPlayer(banId) {
    fetch(`https://${GetParentResourceName()}/unbanPlayer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            banId: banId
        })
    })
    .then(() => {
        loadBans();
        loadDashboardData();
    });
}

// Save settings
function saveSettings() {
    const settings = {
        aimbotDetection: document.getElementById('aimbotDetection').checked,
        espDetection: document.getElementById('espDetection').checked,
        noclipDetection: document.getElementById('noclipDetection').checked,
        superjumpDetection: document.getElementById('superjumpDetection').checked,
        speedhackDetection: document.getElementById('speedhackDetection').checked
    };

    fetch(`https://${GetParentResourceName()}/saveSettings`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
    });
}

// Event listeners for settings changes
document.querySelectorAll('.setting-item input').forEach(input => {
    input.addEventListener('change', saveSettings);
});

// Load blacklist
function loadBlacklist() {
    fetch(`https://${GetParentResourceName()}/getBlacklist`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        updateBlacklistList('weaponsList', data.weapons);
        updateBlacklistList('vehiclesList', data.vehicles);
        updateBlacklistList('keywordsList', data.keywords);
        updateBlacklistList('eventsList', data.events);
    });
}

function updateBlacklistList(listId, items) {
    const list = document.getElementById(listId);
    list.innerHTML = '';
    
    items.forEach(item => {
        const listItem = document.createElement('div');
        listItem.className = 'blacklist-item';
        listItem.innerHTML = `
            <span>${item}</span>
            <button class="danger" onclick="removeBlacklistItem('${listId}', '${item}')">Remove</button>
        `;
        list.appendChild(listItem);
    });
}

function addBlacklistItem(type) {
    const inputId = `new${type.charAt(0).toUpperCase() + type.slice(1)}`;
    const input = document.getElementById(inputId);
    const value = input.value.trim();
    
    if (value) {
        fetch(`https://${GetParentResourceName()}/addBlacklistItem`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                type: type,
                value: value
            })
        })
        .then(() => {
            input.value = '';
            loadBlacklist();
        });
    }
}

function removeBlacklistItem(listId, item) {
    const type = listId.replace('List', '').toLowerCase();
    
    fetch(`https://${GetParentResourceName()}/removeBlacklistItem`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            type: type,
            value: item
        })
    })
    .then(() => {
        loadBlacklist();
    });
}

// Show success notification
function showNotification(message = 'Successfully Saved!', type = 'success') {
    const notification = document.getElementById('successNotification');
    notification.querySelector('p').textContent = message;
    
    if (type === 'error') {
        notification.querySelector('.success-icon i').className = 'fas fa-times';
        notification.querySelector('.success-icon').style.borderColor = '#f44336';
        notification.querySelector('.success-icon i').style.color = '#f44336';
        notification.querySelector('h2').textContent = 'Error';
    } else {
        notification.querySelector('.success-icon i').className = 'fas fa-check';
        notification.querySelector('.success-icon').style.borderColor = '#4CAF50';
        notification.querySelector('.success-icon i').style.color = '#4CAF50';
        notification.querySelector('h2').textContent = 'Success!';
    }
    
    notification.style.display = 'block';
    setTimeout(() => {
        closeNotification();
    }, 3000);
}

// Close notification
function closeNotification() {
    document.getElementById('successNotification').style.display = 'none';
}

// Show modal
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Handle admin actions
function handleAdminAction(action, data = {}) {
    fetch(`https://${GetParentResourceName()}/adminAction`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: action,
            ...data
        })
    }).then(() => {
        showNotification('Action completed successfully!');
    });
}

// Handle Player Actions
function handlePlayerAction(action) {
    switch(action) {
        case 'goto':
            sendToGame('goto', { playerId: selectedPlayer.id });
            break;
        case 'bring':
            sendToGame('bring', { playerId: selectedPlayer.id });
            break;
        case 'spectate':
            isSpectating = true;
            sendToGame('spectate', { playerId: selectedPlayer.id });
            break;
        case 'disableSpectate':
            isSpectating = false;
            sendToGame('disableSpectate', {});
            break;
        case 'watch':
            sendToGame('watchGame', { playerId: selectedPlayer.id });
            break;
        case 'screenshot':
            sendToGame('screenshot', { playerId: selectedPlayer.id });
            break;
        case 'ban':
            showModal('banModal');
            break;
        case 'kick':
            showModal('kickModal');
            break;
    }
}

// Update Players List
function updatePlayersList(playersList) {
    players = playersList;
    renderPlayers();
}

// Render Players
function renderPlayers(filteredPlayers = null) {
    const tbody = document.getElementById('playersList');
    tbody.innerHTML = '';

    const playersToRender = filteredPlayers || players;

    playersToRender.forEach(player => {
        const row = document.createElement('tr');
        row.dataset.id = player.id;
        row.dataset.name = player.name;
        row.dataset.steamhex = player.steamhex;
        
        row.innerHTML = `
            <td>${player.id}</td>
            <td>${player.name}</td>
            <td>${player.steamhex}</td>
        `;

        if (selectedPlayer && selectedPlayer.id === player.id) {
            row.classList.add('selected');
        }

        tbody.appendChild(row);
    });
}

// Initialize vehicles section
function initVehiclesSection() {
    const categoriesList = document.querySelector('.categories-list');
    const vehiclesList = document.querySelector('.vehicles-list');
    
    // Populate categories
    Object.keys(vehicles).forEach(category => {
        const categoryItem = document.createElement('div');
        categoryItem.className = 'category-item';
        categoryItem.textContent = category;
        categoryItem.addEventListener('click', () => selectCategory(category));
        categoriesList.appendChild(categoryItem);
    });

    // Vehicle name input
    const vehicleNameInput = document.querySelector('.vehicle-name-input');
    vehicleNameInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        if (selectedCategory) {
            displayVehicles(selectedCategory, searchTerm);
        }
    });

    // Option buttons
    document.querySelector('.option-button.spawn').addEventListener('click', spawnVehicle);
    document.querySelector('.option-button.delete').addEventListener('click', deleteVehicle);
    document.querySelector('.option-button.repair').addEventListener('click', repairVehicle);
    document.querySelector('.option-button.godmode').addEventListener('click', toggleVehicleGodmode);
}

function selectCategory(category) {
    selectedCategory = category;
    document.querySelectorAll('.category-item').forEach(item => {
        item.classList.toggle('active', item.textContent === category);
    });
    displayVehicles(category);
}

function displayVehicles(category, searchTerm = '') {
    const vehiclesList = document.querySelector('.vehicles-list');
    vehiclesList.innerHTML = '';

    const filteredVehicles = vehicles[category].filter(vehicle => 
        vehicle.toLowerCase().includes(searchTerm)
    );

    filteredVehicles.forEach(vehicle => {
        const vehicleItem = document.createElement('div');
        vehicleItem.className = 'vehicle-item';
        if (selectedVehicle === vehicle) {
            vehicleItem.classList.add('selected');
        }
        vehicleItem.textContent = vehicle;
        vehicleItem.addEventListener('click', () => selectVehicle(vehicle));
        vehiclesList.appendChild(vehicleItem);
    });
}

function selectVehicle(vehicle) {
    selectedVehicle = vehicle;
    document.querySelectorAll('.vehicle-item').forEach(item => {
        item.classList.toggle('selected', item.textContent === vehicle);
    });
    document.querySelector('.vehicle-name-input').value = vehicle;
}

function spawnVehicle() {
    const vehicleName = document.querySelector('.vehicle-name-input').value.trim();
    if (!vehicleName) {
        showNotification('Error', 'Please enter a vehicle name', 'error');
        return;
    }
    sendToGame('spawnVehicle', { vehicle: vehicleName });
    showNotification('Success', `Spawned vehicle: ${vehicleName}`, 'success');
}

function deleteVehicle() {
    sendToGame('deleteVehicle', {});
    showNotification('Success', 'Deleted current vehicle', 'success');
}

function repairVehicle() {
    sendToGame('repairVehicle', {});
    showNotification('Success', 'Repaired current vehicle', 'success');
}

let vehicleGodmode = false;
function toggleVehicleGodmode() {
    vehicleGodmode = !vehicleGodmode;
    sendToGame('toggleVehicleGodmode', { enabled: vehicleGodmode });
    showNotification('Success', `Vehicle godmode ${vehicleGodmode ? 'enabled' : 'disabled'}`, 'success');
    const godmodeButton = document.querySelector('.option-button.godmode');
    godmodeButton.style.opacity = vehicleGodmode ? '1' : '0.7';
} 