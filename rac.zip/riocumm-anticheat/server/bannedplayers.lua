--[[
    RAC AntiCheat Banned Players Management
    Handles banned players storage and unban functionality
]]

local bannedPlayers = {}

-- Load banned players from database on resource start
CreateThread(function()
    MySQL.ready(function()
        MySQL.Async.fetchAll('SELECT * FROM bans', {}, function(results)
            if results then
                for _, ban in ipairs(results) do
                    bannedPlayers[ban.id] = {
                        identifier = ban.identifier,
                        reason = ban.reason,
                        expiration = ban.expiration,
                        banned_by = ban.banned_by
                    }
                end
                print('^2[RAC] Loaded ' .. #results .. ' banned players^7')
            end
        end)
    end)
end)

-- Command to unban a player by ban ID
RegisterCommand('runban', function(source, args)
    -- Check if source has permission
    if source ~= 0 then -- Not console
        if not IsPlayerAceAllowed(source, 'rac.admin') then
            if GetPlayerName(source) then -- Only send message if player exists
                TriggerClientEvent('chat:addMessage', source, {
                    color = {255, 0, 0},
                    args = {'RAC', 'You do not have permission to use this command.'}
                })
            end
            return
        end
    end

    -- Validate arguments
    if not args[1] or not tonumber(args[1]) then
        local target = source ~= 0 and source or nil
        if target then
            TriggerClientEvent('chat:addMessage', target, {
                color = {255, 0, 0},
                args = {'RAC', 'Usage: /runban <ban_id>'}
            })
        else
            print('^1[RAC] Usage: /runban <ban_id>^7')
        end
        return
    end

    local banId = tonumber(args[1])
    
    -- Check if ban exists
    if not bannedPlayers[banId] then
        local target = source ~= 0 and source or nil
        if target then
            TriggerClientEvent('chat:addMessage', target, {
                color = {255, 0, 0},
                args = {'RAC', 'Ban ID ' .. banId .. ' not found.'}
            })
        else
            print('^1[RAC] Ban ID ' .. banId .. ' not found.^7')
        end
        return
    end

    -- Remove ban from database
    MySQL.Async.execute('DELETE FROM bans WHERE id = @id', {
        ['@id'] = banId
    }, function(rowsChanged)
        if rowsChanged > 0 then
            -- Log unban
            local adminName = source ~= 0 and GetPlayerName(source) or 'Console'
            local unbannedIdentifier = bannedPlayers[banId].identifier
            
            -- Send Discord webhook if enabled
            if RAC.Discord.webhookEnabled then
                local embed = {
                    {
                        ["color"] = RAC.Discord.embedColor,
                        ["title"] = "Player Unbanned",
                        ["description"] = string.format("**Ban ID:** %s\n**Identifier:** %s\n**Unbanned By:** %s",
                            banId, unbannedIdentifier, adminName
                        ),
                        ["footer"] = {
                            ["text"] = RAC.Discord.embedFooter
                        },
                        ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
                    }
                }
                
                PerformHttpRequest(RAC.Discord.webhooks.main, function(err, text, headers) end, 'POST', json.encode({
                    username = RAC.Discord.botName,
                    avatar_url = RAC.Discord.botAvatar,
                    embeds = embed
                }), { ['Content-Type'] = 'application/json' })
            end

            -- Remove from local cache
            bannedPlayers[banId] = nil

            -- Notify success
            local target = source ~= 0 and source or nil
            if target then
                TriggerClientEvent('chat:addMessage', target, {
                    color = {0, 255, 0},
                    args = {'RAC', 'Successfully unbanned player with ID ' .. banId}
                })
            else
                print('^2[RAC] Successfully unbanned player with ID ' .. banId .. '^7')
            end
        end
    end)
end, false)

-- Export functions
exports('getBannedPlayers', function()
    return bannedPlayers
end)

exports('isBanned', function(identifier)
    for _, ban in pairs(bannedPlayers) do
        if ban.identifier == identifier then
            return true
        end
    end
    return false
end)

-- Store ban in local cache when a new ban is added
RegisterNetEvent('rac:banAdded')
AddEventHandler('rac:banAdded', function(banData)
    bannedPlayers[banData.id] = {
        identifier = banData.identifier,
        reason = banData.reason,
        expiration = banData.expiration,
        banned_by = banData.banned_by
    }
end) 