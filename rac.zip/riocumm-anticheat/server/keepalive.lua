--[[
    RAC AntiCheat Keep-Alive System
    Monitors client connections and handles disconnections
]]

-- Configuration validation
local function ValidateConfig()
    if not RAC then
        print('^1[RAC] Error: RAC configuration table is missing^7')
        return false
    end
    
    local required = {
        {'HeartBeat.enabled', 'boolean'},
        {'HeartBeat.maxTime', 'number'},
        {'Settings.keepAliveInterval', 'number'},
        {'Settings.chatMessages', 'boolean'}
    }
    
    for _, config in ipairs(required) do
        local value = RAC
        for part in config[1]:gmatch('[^.]+') do
            value = value[part]
            if not value then
                print('^1[RAC] Error: Missing configuration: ' .. config[1] .. '^7')
                return false
            end
        end
        if type(value) ~= config[2] then
            print('^1[RAC] Error: Invalid type for ' .. config[1] .. '. Expected ' .. config[2] .. ', got ' .. type(value) .. '^7')
            return false
        end
    end
    return true
end

-- Validate configuration on resource start
CreateThread(function()
    if not ValidateConfig() then
        print('^1[RAC] Keep-alive system disabled due to configuration errors^7')
        RAC.HeartBeat.enabled = false
        return
    end
end)

local playerHeartbeats = {}
local playerWarnings = {}

-- Initialize keep-alive system
CreateThread(function()
    if not RAC.HeartBeat.enabled then return end
    
    -- Check heartbeats periodically
    while true do
        CheckHeartbeats()
        Wait(RAC.Settings.keepAliveInterval)
    end
end)

-- Register keep-alive event
RegisterNetEvent('rac:keepAlive')
AddEventHandler('rac:keepAlive', function()
    local source = source
    if not source then return end
    
    playerHeartbeats[source] = os.time()
    playerWarnings[source] = playerWarnings[source] or 0
end)

-- Check client heartbeats
function CheckHeartbeats()
    local currentTime = os.time()
    
    for playerId, lastBeat in pairs(playerHeartbeats) do
        if GetPlayerName(playerId) then -- Check if player still exists
            local timeDiff = currentTime - lastBeat
            
            if timeDiff > RAC.HeartBeat.maxTime then
                HandleMissingHeartbeat(playerId)
            end
        else
            -- Clean up disconnected players
            playerHeartbeats[playerId] = nil
            playerWarnings[playerId] = nil
        end
    end
end

-- Handle missing heartbeat
function HandleMissingHeartbeat(playerId)
    if not GetPlayerName(playerId) then return end
    
    playerWarnings[playerId] = playerWarnings[playerId] + 1
    
    if playerWarnings[playerId] >= 3 then
        -- Player has missed too many heartbeats
        local reason = "Connection timeout - No heartbeat received"
        TriggerEvent('rac:detection', playerId, 'heartbeat_failure', {
            warnings = playerWarnings[playerId],
            lastBeat = playerHeartbeats[playerId]
        })
        
        -- Take screenshot if enabled
        if RAC.Screenshot.enabled and RAC.Screenshot.events['rac:timeout'] then
            exports[GetCurrentResourceName()]:takeScreenshot(playerId, "Heartbeat Failure")
        end
        
        -- Drop player
        DropPlayer(playerId, reason)
        
        -- Clean up
        playerHeartbeats[playerId] = nil
        playerWarnings[playerId] = nil
    else
        -- Send warning to client
        TriggerClientEvent('rac:heartbeatWarning', playerId, playerWarnings[playerId])
    end
end

-- Player disconnect handler
AddEventHandler('playerDropped', function(reason)
    local source = source
    
    -- Clean up player data
    playerHeartbeats[source] = nil
    playerWarnings[source] = nil
end)

-- Player connect handler
RegisterNetEvent('rac:playerConnected')
AddEventHandler('rac:playerConnected', function()
    local source = source
    
    -- Initialize heartbeat tracking
    playerHeartbeats[source] = os.time()
    playerWarnings[source] = 0
    
    -- Send initial heartbeat request
    TriggerClientEvent('rac:initHeartbeat', source, RAC.Settings.keepAliveInterval)
end)

-- Exports
exports('getPlayerHeartbeat', function(playerId)
    return playerHeartbeats[playerId] or 0
end)

exports('getPlayerWarnings', function(playerId)
    return playerWarnings[playerId] or 0
end) 