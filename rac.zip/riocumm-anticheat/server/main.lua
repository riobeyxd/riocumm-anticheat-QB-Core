local QBCore = exports['qb-core']:GetCoreObject()
local bannedPlayers = {}
local whitelistedPlayers = {}
local adminPlayers = {}

-- Initialize the anti-cheat system
CreateThread(function()
    LoadBans()
    LoadWhitelist()
    LoadAdmins()
end)

-- Load bans from database
function LoadBans()
    -- Implementation for loading bans from database
end

-- Load whitelist from database
function LoadWhitelist()
    -- Implementation for loading whitelist from database
end

-- Load admins from database
function LoadAdmins()
    -- Implementation for loading admins from database
end

-- Ban player
function BanPlayer(source, reason)
    local player = QBCore.Functions.GetPlayer(source)
    if not player then return end

    local identifiers = GetPlayerIdentifiers(source)
    local banId = GenerateBanId()
    
    -- Add to banned players
    bannedPlayers[banId] = {
        identifiers = identifiers,
        reason = reason,
        timestamp = os.time()
    }

    -- Log to Discord
    SendDiscordLog("ban", {
        playerName = GetPlayerName(source),
        identifiers = identifiers,
        reason = reason,
        banId = banId
    })

    -- Kick player
    DropPlayer(source, Config.BanSystem.banMessage)
end

-- Unban player
function UnbanPlayer(banId)
    if bannedPlayers[banId] then
        bannedPlayers[banId] = nil
        -- Log to Discord
        SendDiscordLog("unban", {
            banId = banId
        })
        return true
    end
    return false
end

-- Check if player is banned
function IsPlayerBanned(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, banData in pairs(bannedPlayers) do
        for _, identifier in pairs(identifiers) do
            if banData.identifiers[identifier] then
                return true, banData
            end
        end
    end
    return false
end

-- Generate unique ban ID
function GenerateBanId()
    return string.format("%08x", math.random(0, 0xFFFFFFFF))
end

-- Get player identifiers
function GetPlayerIdentifiers(source)
    local identifiers = {}
    for _, identifier in pairs(GetPlayerIdentifiers(source)) do
        identifiers[identifier] = true
    end
    return identifiers
end

-- Send Discord log
function SendDiscordLog(type, data)
    if not Config.Logging.enabled then return end

    local embed = {
        title = "Anti-Cheat Log",
        color = 16711680, -- Red
        fields = {
            {name = "Type", value = type, inline = true},
            {name = "Player", value = data.playerName or "N/A", inline = true},
            {name = "Reason", value = data.reason or "N/A", inline = true},
            {name = "Ban ID", value = data.banId or "N/A", inline = true},
            {name = "Timestamp", value = os.date("%Y-%m-%d %H:%M:%S"), inline = true}
        }
    }

    -- Add identifiers if available
    if data.identifiers then
        for identifier, _ in pairs(data.identifiers) do
            table.insert(embed.fields, {name = "Identifier", value = identifier, inline = true})
        end
    end

    PerformHttpRequest(Config.DiscordWebhook, function(err, text, headers) end, 'POST', json.encode({embeds = {embed}}), { ['Content-Type'] = 'application/json' })
end

-- Register commands
RegisterCommand('rban', function(source, args)
    if source == 0 then
        local targetId = tonumber(args[1])
        local reason = table.concat(args, " ", 2)
        if targetId and reason then
            BanPlayer(targetId, reason)
        end
    end
end)

RegisterCommand('runban', function(source, args)
    if source == 0 then
        local banId = args[1]
        if banId then
            UnbanPlayer(banId)
        end
    end
end)

RegisterCommand('raddwhitelist', function(source, args)
    if source == 0 then
        local identifier = args[1]
        if identifier then
            whitelistedPlayers[identifier] = true
            -- Save to database
        end
    end
end)

RegisterCommand('radmin', function(source, args)
    if source == 0 then
        local identifier = args[1]
        if identifier then
            adminPlayers[identifier] = true
            -- Save to database
        end
    end
end)

-- Event handlers
RegisterNetEvent('riocumm-anticheat:server:detection')
AddEventHandler('riocumm-anticheat:server:detection', function(detectionType, data)
    local source = source
    if not IsPlayerWhitelisted(source) then
        local reason = "Cheat detected: " .. detectionType
        local details = ""
        
        if detectionType == "blacklisted_weapon" then
            details = "Blacklisted weapon: " .. data.weapon
        elseif detectionType == "blacklisted_vehicle" then
            details = "Blacklisted vehicle: " .. data.vehicle
        elseif detectionType == "blacklisted_keyword" then
            details = "Blacklisted keyword: " .. data.keyword .. " in message: " .. data.message
        elseif detectionType == "blacklisted_event" then
            details = "Blacklisted event triggered: " .. data.event
        end
        
        BanPlayer(source, reason .. " - " .. details)
    end
end)

-- Monitor resource starts
AddEventHandler('onResourceStart', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        -- Block blacklisted events
        for _, event in ipairs(Config.Blacklist.Events.list) do
            RegisterNetEvent(event)
            AddEventHandler(event, function()
                local source = source
                if not IsPlayerWhitelisted(source) then
                    BanPlayer(source, "Attempted to trigger blacklisted event: " .. event)
                end
            end)
        end
    end
end)

-- Check if player is whitelisted
function IsPlayerWhitelisted(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, identifier in pairs(identifiers) do
        if whitelistedPlayers[identifier] then
            return true
        end
    end
    return false
end

-- Check if player is admin
function IsPlayerAdmin(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, identifier in pairs(identifiers) do
        if adminPlayers[identifier] then
            return true
        end
    end
    return false
end 