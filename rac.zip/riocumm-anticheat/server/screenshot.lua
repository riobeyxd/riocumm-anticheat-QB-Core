--[[
    RAC AntiCheat Screenshot System
    Handles screenshot capture, storage, and Discord integration
]]

local QBCore = nil
local ESX = nil

-- Framework Detection
CreateThread(function()
    if GetResourceState('es_extended') == 'started' then
        ESX = exports['es_extended']:getSharedObject()
    elseif GetResourceState('qb-core') == 'started' then
        QBCore = exports['qb-core']:GetCoreObject()
    end
end)

-- Screenshot Queue System
local screenshotQueue = {}
local isProcessingQueue = false

-- Initialize screenshot directory
CreateThread(function()
    if not RAC.Screenshot.enabled then return end
    
    if RAC.Screenshot.saveLocal then
        local path = GetResourcePath(GetCurrentResourceName()) .. '/' .. RAC.Screenshot.savePath
        if not DoesDirectoryExist(path) then
            os.execute('mkdir "' .. path .. '"')
        end
    end
end)

-- Screenshot Request Handler
RegisterNetEvent('rac:takeScreenshot')
AddEventHandler('rac:takeScreenshot', function(playerId, reason)
    if not RAC.Screenshot.enabled then return end
    
    local source = source
    if not IsPlayerAceAllowed(source, 'rac.admin') and source ~= '' then return end
    
    QueueScreenshot(playerId, reason)
end)

-- Screenshot Processing
function QueueScreenshot(playerId, reason)
    if not playerId or not GetPlayerName(playerId) then return end
    
    table.insert(screenshotQueue, {
        playerId = playerId,
        reason = reason,
        timestamp = os.time()
    })
    
    if not isProcessingQueue then
        ProcessScreenshotQueue()
    end
end

function ProcessScreenshotQueue()
    if #screenshotQueue == 0 then
        isProcessingQueue = false
        return
    end
    
    isProcessingQueue = true
    local task = screenshotQueue[1]
    
    exports['screenshot-basic']:requestClientScreenshot(task.playerId, {
        encoding = RAC.Screenshot.encoding,
        quality = RAC.Settings.screenshotQuality,
        retryMode = true,
        retryTimeout = RAC.Settings.screenshotTimeout,
        retryCount = RAC.Screenshot.maxRetries
    }, function(err, data)
        if err then
            print('^1[RAC] Failed to take screenshot: ' .. err .. '^7')
        else
            HandleScreenshotData(task.playerId, data, task.reason, task.timestamp)
        end
        
        table.remove(screenshotQueue, 1)
        SetTimeout(RAC.Screenshot.retryDelay, ProcessScreenshotQueue)
    end)
end

-- Screenshot Data Handler
function HandleScreenshotData(playerId, data, reason, timestamp)
    local player = GetPlayerName(playerId)
    if not player then return end
    
    -- Save locally if enabled
    if RAC.Screenshot.saveLocal then
        local path = GetResourcePath(GetCurrentResourceName()) .. '/' .. RAC.Screenshot.savePath
        local fileName = string.format('%s_%s_%s.%s', 
            player:gsub('%W', ''), 
            os.date('%Y%m%d_%H%M%S', timestamp),
            reason:gsub('%W', ''),
            RAC.Screenshot.encoding
        )
        
        SaveScreenshotToFile(path .. fileName, data)
    end
    
    -- Send to Discord if enabled
    if RAC.Screenshot.webhookEnabled then
        local identifiers = GetPlayerIdentifiers(playerId)
        local steamid = "Unknown"
        local license = "Unknown"
        local discord = "Unknown"
        
        for _, id in ipairs(identifiers) do
            if string.find(id, "steam") then
                steamid = id
            elseif string.find(id, "license") then
                license = id
            elseif string.find(id, "discord") then
                discord = id:gsub("discord:", "")
            end
        end
        
        local embed = {
            {
                ["color"] = RAC.Discord.embedColor,
                ["title"] = "Screenshot Taken",
                ["description"] = string.format("**Reason:** %s\n**Player:** %s\n**Steam:** %s\n**License:** %s\n**Discord:** <@%s>",
                    reason, player, steamid, license, discord
                ),
                ["footer"] = {
                    ["text"] = RAC.Discord.embedFooter
                },
                ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ", timestamp)
            }
        }
        
        PerformHttpRequest(RAC.Discord.webhooks.screenshots, function(err, text, headers) end, 'POST', json.encode({
            username = RAC.Discord.botName,
            avatar_url = RAC.Discord.botAvatar,
            embeds = embed,
            file = data
        }), { ['Content-Type'] = 'application/json' })
    end
end

-- Utility Functions
function SaveScreenshotToFile(path, data)
    local file = io.open(path, 'wb')
    if file then
        file:write(data)
        file:close()
    end
end

function DoesDirectoryExist(path)
    local ok, err, code = os.rename(path, path)
    if not ok and code == 13 then
        return true
    end
    return ok
end

-- Export functions
exports('takeScreenshot', QueueScreenshot)
exports('isScreenshotEnabled', function() return RAC.Screenshot.enabled end)

-- Configuration validation
local function ValidateConfig()
    if not RAC then
        print('^1[RAC] Error: RAC configuration table is missing^7')
        return false
    end
    
    local required = {
        {'Screenshot.enabled', 'boolean'},
        {'Screenshot.saveLocal', 'boolean'},
        {'Screenshot.savePath', 'string'},
        {'Screenshot.encoding', 'string'},
        {'Screenshot.webhookEnabled', 'boolean'},
        {'Settings.screenshotQuality', 'number'},
        {'Settings.screenshotTimeout', 'number'},
        {'Discord.webhooks.screenshots', 'string'},
        {'Discord.embedColor', 'number'},
        {'Discord.embedFooter', 'string'},
        {'Discord.botName', 'string'},
        {'Discord.botAvatar', 'string'}
    }
    
    for _, config in ipairs(required) do
        local value = RAC
        for part in config[1]:gmatch('[^.]+') do
            value = value[part]
            if not value then
                print('^1[RAC] Error: Missing configuration: ' .. config[1] .. '^7')
                return false
            end
        end
        if type(value) ~= config[2] then
            print('^1[RAC] Error: Invalid type for ' .. config[1] .. '. Expected ' .. config[2] .. ', got ' .. type(value) .. '^7')
            return false
        end
    end
    return true
end

-- Validate configuration on resource start
CreateThread(function()
    if not ValidateConfig() then
        print('^1[RAC] Screenshot system disabled due to configuration errors^7')
        RAC.Screenshot.enabled = false
        return
    end
end) 