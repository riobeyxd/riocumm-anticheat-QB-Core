-- Webhook cooldown tracking
local lastWebhookTime = {}

-- Format timestamp for logs
local function formatTimestamp()
    return os.date("%Y-%m-%d %H:%M:%S")
end

-- Get player identifiers
local function getPlayerIdentifiers(source)
    local identifiers = {
        steam = "",
        discord = "",
        license = "",
        ip = ""
    }
    
    for _, v in pairs(GetPlayerIdentifiers(source)) do
        if string.find(v, "steam") then
            identifiers.steam = v
        elseif string.find(v, "discord") then
            identifiers.discord = v
        elseif string.find(v, "license") then
            identifiers.license = v
        elseif string.find(v, "ip") then
            identifiers.ip = v
        end
    end
    
    return identifiers
end

-- Format player info for logs
local function formatPlayerInfo(source)
    local identifiers = getPlayerIdentifiers(source)
    local name = GetPlayerName(source) or "Unknown"
    local coords = GetEntityCoords(GetPlayerPed(source))
    
    return {
        id = source,
        name = name,
        steam = identifiers.steam,
        discord = identifiers.discord,
        license = identifiers.license,
        position = coords,
        timestamp = formatTimestamp()
    }
end

-- Send webhook with cooldown check
local function sendWebhook(webhookType, title, description, fields)
    if not Config.Webhooks.enabled or not Config.Webhooks.urls[webhookType] then return end
    
    -- Check cooldown
    local currentTime = os.time()
    if lastWebhookTime[webhookType] and 
       (currentTime - lastWebhookTime[webhookType]) < (Config.Webhooks.settings.cooldown[webhookType] or 0) then
        return
    end
    
    -- Update cooldown
    lastWebhookTime[webhookType] = currentTime
    
    -- Prepare embed
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["color"] = Config.Webhooks.colors[webhookType],
            ["footer"] = {
                ["text"] = "RAC Anti-Cheat | " .. formatTimestamp()
            },
            ["fields"] = fields
        }
    }
    
    -- Send to Discord
    PerformHttpRequest(Config.Webhooks.urls[webhookType], function(err, text, headers) end, 'POST', json.encode({
        username = Config.Webhooks.username,
        avatar_url = Config.Webhooks.avatar_url,
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end

-- Log item drop
function LogItemDrop(source, item, count, coords)
    if not Config.Webhooks.settings.log_item_drops then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Item Details",
            ["value"] = string.format("**Item:** %s\n**Count:** %s\n**Location:** %s", 
                item, count, coords),
            ["inline"] = false
        }
    }
    
    sendWebhook("item_drops", 
        "[ITEM DROP LOG]", 
        string.format("Player dropped item at %s", playerInfo.timestamp),
        fields)
end

-- Log vehicle spawn
function LogVehicleSpawn(source, model, coords)
    if not Config.Webhooks.settings.log_vehicle_spawns then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Vehicle Details",
            ["value"] = string.format("**Model:** %s\n**Location:** %s", 
                model, coords),
            ["inline"] = false
        }
    }
    
    sendWebhook("vehicle_spawns", 
        "[VEHICLE SPAWN LOG]", 
        string.format("Player spawned vehicle at %s", playerInfo.timestamp),
        fields)
end

-- Log weapon usage
function LogWeaponUsage(source, weapon, action, details)
    if not Config.Webhooks.settings.log_weapon_usage then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Weapon Details",
            ["value"] = string.format("**Weapon:** %s\n**Action:** %s\n**Details:** %s", 
                weapon, action, details),
            ["inline"] = false
        }
    }
    
    sendWebhook("weapon_usage", 
        "[WEAPON USE LOG]", 
        string.format("Player weapon action at %s", playerInfo.timestamp),
        fields)
end

-- Log ban/kick
function LogBanKick(source, action, reason, banId)
    if not Config.Webhooks.settings.log_bans_kicks then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Action Details",
            ["value"] = string.format("**Action:** %s\n**Reason:** %s\n**Ban ID:** %s", 
                action, reason, banId or "N/A"),
            ["inline"] = false
        }
    }
    
    sendWebhook("bans_kicks", 
        string.format("[PLAYER %s LOG]", string.upper(action)), 
        string.format("Player was %s at %s", action, playerInfo.timestamp),
        fields)
end

-- Log suspicious activity
function LogSuspiciousActivity(source, activityType, details)
    if not Config.Webhooks.settings.log_suspicious_activity then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Activity Details",
            ["value"] = string.format("**Type:** %s\n**Details:** %s", 
                activityType, details),
            ["inline"] = false
        }
    }
    
    sendWebhook("suspicious_activity", 
        "[SUSPICIOUS ACTIVITY LOG]", 
        string.format("Suspicious activity detected at %s", playerInfo.timestamp),
        fields)
end

-- Log admin action
function LogAdminAction(source, action, target, details)
    if not Config.Webhooks.settings.log_admin_actions then return end
    
    local adminInfo = formatPlayerInfo(source)
    local targetInfo = target and formatPlayerInfo(target) or nil
    
    local fields = {
        {
            ["name"] = "Admin Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                adminInfo.id, adminInfo.name, adminInfo.steam, adminInfo.discord),
            ["inline"] = false
        }
    }
    
    if targetInfo then
        table.insert(fields, {
            ["name"] = "Target Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                targetInfo.id, targetInfo.name, targetInfo.steam, targetInfo.discord),
            ["inline"] = false
        })
    end
    
    table.insert(fields, {
        ["name"] = "Action Details",
        ["value"] = string.format("**Action:** %s\n**Details:** %s", 
            action, details or "No details provided"),
        ["inline"] = false
    })
    
    sendWebhook("admin_actions", 
        "[ADMIN ACTION LOG]", 
        string.format("Admin action performed at %s", adminInfo.timestamp),
        fields)
end

-- Log player connection
function LogConnection(source, action)
    if not Config.Webhooks.settings.log_connections then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        }
    }
    
    sendWebhook("connections", 
        string.format("[PLAYER %s LOG]", string.upper(action)), 
        string.format("Player %s at %s", action, playerInfo.timestamp),
        fields)
end

-- Log inventory action
function LogInventoryAction(source, action, item, count, container)
    if not Config.Webhooks.settings.log_inventory_actions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Inventory Action",
            ["value"] = string.format("**Action:** %s\n**Item:** %s\n**Count:** %s\n**Container:** %s", 
                action, item, count, container),
            ["inline"] = false
        }
    }
    
    sendWebhook("inventory_actions", 
        "[INVENTORY ACTION LOG]", 
        string.format("Player performed inventory action at %s", playerInfo.timestamp),
        fields)
end

-- Log bank transaction
function LogBankTransaction(source, action, amount, newBalance, reason)
    if not Config.Webhooks.settings.log_bank_transactions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Transaction Details",
            ["value"] = string.format("**Action:** %s\n**Amount:** $%s\n**New Balance:** $%s\n**Reason:** %s", 
                action, amount, newBalance, reason),
            ["inline"] = false
        }
    }
    
    sendWebhook("bank_transactions", 
        "[BANK TRANSACTION LOG]", 
        string.format("Player performed bank transaction at %s", playerInfo.timestamp),
        fields)
end

-- Log player death
function LogPlayerDeath(source, killer, weapon, coords)
    if not Config.Webhooks.settings.log_player_deaths then return end
    
    local playerInfo = formatPlayerInfo(source)
    local killerInfo = killer and formatPlayerInfo(killer) or nil
    
    local fields = {
        {
            ["name"] = "Victim Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        }
    }
    
    if killerInfo then
        table.insert(fields, {
            ["name"] = "Killer Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                killerInfo.id, killerInfo.name, killerInfo.steam, killerInfo.discord),
            ["inline"] = false
        })
    end
    
    table.insert(fields, {
        ["name"] = "Death Details",
        ["value"] = string.format("**Weapon:** %s\n**Location:** %s", 
            weapon or "Unknown", coords),
        ["inline"] = false
    })
    
    sendWebhook("player_deaths", 
        "[PLAYER DEATH LOG]", 
        string.format("Player death occurred at %s", playerInfo.timestamp),
        fields)
end

-- Log chat message
function LogChatMessage(source, messageType, message, target)
    if not Config.Webhooks.settings.log_chat_messages then return end
    
    local playerInfo = formatPlayerInfo(source)
    local targetInfo = target and formatPlayerInfo(target) or nil
    
    local fields = {
        {
            ["name"] = "Sender Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Message Details",
            ["value"] = string.format("**Type:** %s\n**Content:** %s", 
                messageType, message),
            ["inline"] = false
        }
    }
    
    if targetInfo then
        table.insert(fields, {
            ["name"] = "Recipient Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                targetInfo.id, targetInfo.name, targetInfo.steam, targetInfo.discord),
            ["inline"] = false
        })
    end
    
    sendWebhook("chat_messages", 
        "[CHAT MESSAGE LOG]", 
        string.format("Chat message sent at %s", playerInfo.timestamp),
        fields)
end

-- Log job action
function LogJobAction(source, action, job, grade, oldJob, oldGrade)
    if not Config.Webhooks.settings.log_job_actions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Job Details",
            ["value"] = string.format("**Action:** %s\n**New Job:** %s (Grade %s)\n**Previous Job:** %s (Grade %s)", 
                action, job, grade, oldJob or "None", oldGrade or "N/A"),
            ["inline"] = false
        }
    }
    
    sendWebhook("job_actions", 
        "[JOB ACTION LOG]", 
        string.format("Job action performed at %s", playerInfo.timestamp),
        fields)
end

-- Log property action
function LogPropertyAction(source, action, propertyId, propertyType, details)
    if not Config.Webhooks.settings.log_property_actions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Property Details",
            ["value"] = string.format("**Action:** %s\n**Property ID:** %s\n**Type:** %s\n**Details:** %s", 
                action, propertyId, propertyType, details),
            ["inline"] = false
        }
    }
    
    sendWebhook("property_actions", 
        "[PROPERTY ACTION LOG]", 
        string.format("Property action performed at %s", playerInfo.timestamp),
        fields)
end

-- Log trading action
function LogTradingAction(source, target, action, items, amount)
    if not Config.Webhooks.settings.log_trading_actions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local targetInfo = target and formatPlayerInfo(target) or nil
    
    local fields = {
        {
            ["name"] = "Initiator Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        }
    }
    
    if targetInfo then
        table.insert(fields, {
            ["name"] = "Target Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                targetInfo.id, targetInfo.name, targetInfo.steam, targetInfo.discord),
            ["inline"] = false
        })
    end
    
    table.insert(fields, {
        ["name"] = "Trade Details",
        ["value"] = string.format("**Action:** %s\n**Items:** %s\n**Amount:** %s", 
            action, items, amount),
        ["inline"] = false
    })
    
    sendWebhook("trading_actions", 
        "[TRADING ACTION LOG]", 
        string.format("Trading action performed at %s", playerInfo.timestamp),
        fields)
end

-- Log crafting action
function LogCraftingAction(source, recipe, ingredients, result, quantity)
    if not Config.Webhooks.settings.log_crafting_actions then return end
    
    local playerInfo = formatPlayerInfo(source)
    local fields = {
        {
            ["name"] = "Player Information",
            ["value"] = string.format("**ID:** %s\n**Name:** %s\n**Steam:** %s\n**Discord:** %s", 
                playerInfo.id, playerInfo.name, playerInfo.steam, playerInfo.discord),
            ["inline"] = false
        },
        {
            ["name"] = "Crafting Details",
            ["value"] = string.format("**Recipe:** %s\n**Ingredients:** %s\n**Result:** %s\n**Quantity:** %s", 
                recipe, ingredients, result, quantity),
            ["inline"] = false
        }
    }
    
    sendWebhook("crafting_actions", 
        "[CRAFTING ACTION LOG]", 
        string.format("Crafting action performed at %s", playerInfo.timestamp),
        fields)
end 